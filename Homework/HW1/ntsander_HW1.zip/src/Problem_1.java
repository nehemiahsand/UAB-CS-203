public class Problem_1 {
    public static void main(String[] args) {

        //Create a counter to print
        int counter = 1;
        //Loop through 100 times
        for (int i = 0; i < 100; i++) {
            //Check all the different cases and add one to counter
            //if divisible by 3 and 5
            if ((counter % 3 == 0) && (counter % 5 == 0)) {
                System.out.println("FizzBuzz");
                counter++;
            }
            //if divisible by 3
            else if (counter % 3 == 0) {
                System.out.println("Fizz");
                counter++;
            }
            //if divisible by 5
            else if (counter % 5 == 0) {
                System.out.println("Buzz");
                counter++;
            }
            else {
                System.out.println(counter);
                counter++;
            }
        }
    }
}
